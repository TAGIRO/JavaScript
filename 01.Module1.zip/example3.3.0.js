function init(){
    console.log('page loaded and DOM is ready')
    input  = document.getElementById('inputField');
    output = document.getElementById('theDiv');
}

/*
The showWhatWeTyped function called each time 
we type a single key in the input field
*/
function showWhatWeTyped(){
output.innerHTML = input.value;
}