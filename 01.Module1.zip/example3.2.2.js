var divElem;
var currentImage = 0;
var leftPos = 0

function init(){
    console.log("page loaded and DOM is ready");

    divElem = document.getElementById('theDiv');
}

function animateMario(){
    drawMario(currentImage);
    //next time, show next sprite/subimage
    currentImage = (currentImage + 1) % 3;
    //next time, move mario 5 pixels to the right
    leftPos += 5;
    //And if mario moved 100 pixels, start back from the left
    if(leftPos >= 100)
        leftPos = 0;
    
}

function drawMario(indexImage){
    //remove the text inside the div
    divElem.innerHTML = "";
    //sest th left pos of the div using the left margin
    divElem.style.marginLeft = leftPos  + 'px';
    //change the width and height of the div
    divElem.style.height = '33px';
    divElem.style.width = '22px';
    //remove the background color
    divElem.style.backgroundColor = 'transparent';
    //select the starting pos in the background image
    let offset = indexImage * 24;
    divElem.style.backgroundPosition = offset + 'px';
    //set the background image
    divElem.style.backgroundImage = 'url("images/marioSprite.png")';

}