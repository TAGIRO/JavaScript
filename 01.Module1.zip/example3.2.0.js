function init(){
    console.log("This is to ensure that the page is loaded and the DOM is ready")

    //use the selection API to select the div
    divElem = document.getElementById('theDiv')
    /*as you can  see that divElem is ot declare with var
    which turn to a global variable, that could be access
    out of this funtion
    */
}

function changeStyle() {
    console.log("add border");
    divElem.style.border = "5px dashed purple"
    divElem.style.padding = "10px";
    divElem.style.backgroundColor = 'lightgreen';
}